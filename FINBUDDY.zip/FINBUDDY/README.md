# FINBUDDY: AI-Powered Finance Assistant

This project is a Python Flask application that simulates UPI payment gateways (like GPay, PhonePe) and provides AI-driven financial analysis and recommendations. It includes:

- Dummy database structure for UPI transactions
- Flask backend API for transaction history, payment analysis, budgeting, saving, and investment suggestions
- Basic AI logic for financial insights
- Simple frontend using Flask templates

## Getting Started
1. Install Python 3.10+
2. Create a virtual environment and activate it
3. Install dependencies: `pip install -r requirements.txt`
4. Run the app: `python app.py`

## Features
- Simulate UPI transactions
- Analyze monthly payments and spending
- Get recommendations for saving and investing
- Simple dashboard for financial summary

## Folder Structure
- `app.py`: Main Flask application
- `models.py`: Database models (dummy structure)
- `ai_agent.py`: AI logic for analysis and recommendations
- `templates/`: HTML templates for frontend
- `static/`: Static files (CSS, JS)
- `requirements.txt`: Python dependencies

---
Replace dummy data and logic with real integrations as needed.