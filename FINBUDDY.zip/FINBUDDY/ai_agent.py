# AI Agent for financial analysis and recommendations

def analyze_transactions(transactions):
    total_credit = sum(t['amount'] for t in transactions if t['type'] == 'credit')
    total_debit = sum(t['amount'] for t in transactions if t['type'] == 'debit')
    balance = total_credit - total_debit
    monthly_target = total_credit * 0.7  # Suggest saving 30%
    return {
        'total_credit': total_credit,
        'total_debit': total_debit,
        'balance': balance,
        'suggested_monthly_target': monthly_target
    }

def get_recommendations(transactions):
    analysis = analyze_transactions(transactions)
    invest_amount = analysis['balance'] * 0.2 if analysis['balance'] > 0 else 0
    save_amount = analysis['balance'] * 0.5 if analysis['balance'] > 0 else 0
    spend_amount = analysis['balance'] * 0.3 if analysis['balance'] > 0 else 0
    return {
        'save': f'Save at least ₹{save_amount:.2f} this month.',
        'invest': f'Consider investing ₹{invest_amount:.2f} in mutual funds or FD.',
        'spend': f'Limit discretionary spending to ₹{spend_amount:.2f}.',
        'tips': [
            'Track your expenses regularly.',
            'Pay bills before due dates.',
            'Review investment options monthly.'
        ]
    }
