# Dummy database for UPI transactions (PhonePe/GPay clone)
transactions_db = [
    {
        'id': 1,
        'date': '2025-09-01',
        'amount': 1200,
        'type': 'credit',
        'description': 'Salary',
        'gateway': 'PhonePe'
    },
    {
        'id': 2,
        'date': '2025-09-03',
        'amount': 200,
        'type': 'debit',
        'description': 'Groceries',
        'gateway': 'GPay'
    },
    {
        'id': 3,
        'date': '2025-09-05',
        'amount': 500,
        'type': 'debit',
        'description': 'Electricity Bill',
        'gateway': 'PhonePe'
    },
    {
        'id': 4,
        'date': '2025-09-10',
        'amount': 300,
        'type': 'debit',
        'description': 'Dining Out',
        'gateway': 'GPay'
    }
]
