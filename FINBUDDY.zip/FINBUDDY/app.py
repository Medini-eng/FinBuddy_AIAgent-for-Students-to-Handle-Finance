# For graph generation
import io
import base64
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, jsonify
from models import transactions_db
from ai_agent import analyze_transactions, get_recommendations

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', transactions=transactions_db)

# Transaction management UI
# Transaction management UI
@app.route('/manage')
def manage():
    return render_template('manage.html')

# AI Agent chat UI
@app.route('/ai_chat')
def ai_chat():
    return render_template('ai_chat.html')


# Add new transaction endpoint
# Add new transaction endpoint
@app.route('/api/add_transaction', methods=['POST'])
def add_transaction():
    data = request.get_json()
    new_id = max(t['id'] for t in transactions_db) + 1 if transactions_db else 1
    transaction = {
        'id': new_id,
        'date': data['date'],
        'amount': data['amount'],
        'type': data['type'],
        'description': data['description'],
        'gateway': data['gateway']
    }
    transactions_db.append(transaction)
    return jsonify({'message': 'Transaction added successfully!', 'transaction': transaction})

# AI chat endpoint
@app.route('/api/ai_chat', methods=['POST'])
def api_ai_chat():
    data = request.get_json()
    query = data.get('query', '').lower()
    # Simple intent matching
    if 'summary' in query or 'balance' in query:
        analysis = analyze_transactions(transactions_db)
        response = f"Total Credit: ₹{analysis['total_credit']}, Total Debit: ₹{analysis['total_debit']}, Balance: ₹{analysis['balance']}, Suggested Monthly Target: ₹{analysis['suggested_monthly_target']}"
    elif 'recommend' in query or 'invest' in query or 'save' in query:
        recs = get_recommendations(transactions_db)
        response = f"{recs['save']} {recs['invest']} {recs['spend']}"
    elif 'graph' in query or 'visual' in query or 'trend' in query:
        # Generate a monthly debit/credit graph
        dates = [t['date'] for t in transactions_db]
        credits = [t['amount'] if t['type']=='credit' else 0 for t in transactions_db]
        debits = [t['amount'] if t['type']=='debit' else 0 for t in transactions_db]
        plt.figure(figsize=(6,3))
        plt.plot(dates, credits, label='Credit', marker='o', color='green')
        plt.plot(dates, debits, label='Debit', marker='o', color='red')
        plt.xticks(rotation=45)
        plt.legend()
        plt.tight_layout()
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        graph_url = 'data:image/png;base64,' + base64.b64encode(buf.read()).decode('utf-8')
        plt.close()
        response = 'Here is your transaction trend graph.'
        return jsonify({'response': response, 'graph': graph_url})
    else:
        response = "Ask me about your balance, monthly summary, recommendations, or trends!"
    return jsonify({'response': response})

@app.route('/api/transactions')
def get_transactions():
    return jsonify(transactions_db)

@app.route('/api/analyze')
def analyze():
    analysis = analyze_transactions(transactions_db)
    return jsonify(analysis)

@app.route('/api/recommendations')
def recommendations():
    recs = get_recommendations(transactions_db)
    return jsonify(recs)

if __name__ == '__main__':
    app.run(debug=True)
